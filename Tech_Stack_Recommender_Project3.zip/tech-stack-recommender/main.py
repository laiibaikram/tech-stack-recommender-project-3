"""
Tech Stack Recommender
DecodeLabs - Artificial Intelligence Project 3

A content-based recommendation system that matches a user's skills
with technology career roles using TF-IDF and cosine similarity.
"""

import csv
from pathlib import Path

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


BASE_DIR = Path(__file__).resolve().parent
DATASET_PATH = BASE_DIR / "raw_skills.csv"
TOP_N = 3


def load_roles(csv_path=DATASET_PATH):
    """Load career roles and their skill descriptions from the CSV dataset."""
    roles = []
    with open(csv_path, "r", newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)
        required_columns = {"role", "skills", "description"}
        if not required_columns.issubset(reader.fieldnames or []):
            raise ValueError(
                "Dataset must contain these columns: role, skills, description."
            )

        for row in reader:
            roles.append({
                "role": row["role"].strip(),
                "skills": row["skills"].strip(),
                "description": row["description"].strip(),
            })

    if not roles:
        raise ValueError("The dataset is empty. Add career roles to raw_skills.csv.")

    return roles


def get_user_skills(available_skills):
    """Collect at least three skills and validate them against dataset vocabulary."""
    print("\nEnter at least 3 skills separated by commas.")
    print("Example: Python, SQL, Machine Learning")
    print("\nSkills available in this dataset:")
    print(", ".join(available_skills))

    while True:
        raw_input = input("\nYour skills: ").strip()
        selected = [skill.strip() for skill in raw_input.split(",") if skill.strip()]

        # Remove duplicate entries while preserving their original order.
        selected = list(dict.fromkeys(skill.lower() for skill in selected))

        if len(selected) < 3:
            print("Please enter at least 3 different skills.")
            continue

        valid_lookup = {skill.lower(): skill for skill in available_skills}
        matched = [valid_lookup[skill] for skill in selected if skill in valid_lookup]
        unknown = [skill for skill in selected if skill not in valid_lookup]

        if unknown:
            print("These skills are not in the dataset:", ", ".join(unknown))
            print("Please use the available skill names shown above.")
            continue

        if len(matched) < 3:
            print("Please select at least 3 valid skills from the dataset.")
            continue

        return matched


def recommend_roles(user_skills, roles, top_n=TOP_N):
    """
    Create TF-IDF vectors for the career-role documents and user profile.
    Calculate cosine similarity, sort scores, and return the Top-N roles.
    """
    role_documents = [
        f"{role['skills']} {role['description']}" for role in roles
    ]
    user_document = " ".join(user_skills)

    # Fit TF-IDF on all role documents plus the user's profile so they share
    # exactly the same vocabulary and vector space.
    all_documents = role_documents + [user_document]
    vectorizer = TfidfVectorizer(stop_words="english")
    vectors = vectorizer.fit_transform(all_documents)

    role_vectors = vectors[:-1]
    user_vector = vectors[-1]

    # A zero vector means none of the user's terms were represented.
    if user_vector.nnz == 0:
        return []

    scores = cosine_similarity(user_vector, role_vectors).flatten()

    ranked_indices = sorted(
        range(len(scores)),
        key=lambda index: scores[index],
        reverse=True
    )

    recommendations = []
    for index in ranked_indices:
        if scores[index] <= 0:
            continue
        recommendations.append({
            "role": roles[index]["role"],
            "skills": roles[index]["skills"],
            "description": roles[index]["description"],
            "score": float(scores[index]),
        })
        if len(recommendations) == top_n:
            break

    return recommendations


def main():
    print("=" * 58)
    print("             TECH STACK RECOMMENDER")
    print("       DecodeLabs | Artificial Intelligence Project 3")
    print("=" * 58)
    print("Find career roles that match your technical skills.")

    try:
        roles = load_roles()
        available_skills = sorted({
            skill.strip()
            for role in roles
            for skill in role["skills"].split(",")
            if skill.strip()
        })

        user_skills = get_user_skills(available_skills)
        print("\nYour selected skills:", ", ".join(user_skills))
        print("\nAnalysing your profile with TF-IDF and cosine similarity...")

        recommendations = recommend_roles(user_skills, roles)

        print("\n" + "=" * 58)
        print("             YOUR TOP 3 CAREER MATCHES")
        print("=" * 58)

        if not recommendations:
            print("No close match was found in the current dataset.")
            print("Try selecting skills from the available dataset vocabulary.")
            return

        for rank, item in enumerate(recommendations, start=1):
            percentage = item["score"] * 100
            print(f"\n{rank}. {item['role']}")
            print(f"   Match score: {percentage:.2f}%")
            print(f"   Relevant skills: {item['skills']}")
            print(f"   Role overview: {item['description']}")

        print("\n" + "-" * 58)
        print("Note: Match scores show text similarity, not a guarantee")
        print("of job eligibility or employment.")
        print("-" * 58)

    except FileNotFoundError:
        print(f"Dataset not found: {DATASET_PATH}")
        print("Make sure raw_skills.csv is in the same folder as main.py.")
    except (ValueError, csv.Error) as error:
        print("Project data error:", error)


if __name__ == "__main__":
    main()
